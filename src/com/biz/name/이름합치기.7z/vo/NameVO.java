package com.biz.name.vo;

public class NameVO {

	String strSurName;
	String strName;
	String strNum1;
	String strHan;
	String strNum2;
	@Override
	public String toString() {
		return "NameVO [strSurName=" + strSurName + ", strName=" + strName + ", strNum1=" + strNum1 + ", strHan="
				+ strHan + ", strNum2=" + strNum2 + "]";
	}
	public String getStrSurName() {
		return strSurName;
	}
	public void setStrSurName(String strSurName) {
		this.strSurName = strSurName;
	}
	public String getStrName() {
		return strName;
	}
	public void setStrName(String strName) {
		this.strName = strName;
	}
	public String getStrNum1() {
		return strNum1;
	}
	public void setStrNum1(String strNum1) {
		this.strNum1 = strNum1;
	}
	public String getStrHan() {
		return strHan;
	}
	public void setStrHan(String strHan) {
		this.strHan = strHan;
	}
	public String getStrNum2() {
		return strNum2;
	}
	public void setStrNum2(String strNum2) {
		this.strNum2 = strNum2;
	}

	
	
	
}
