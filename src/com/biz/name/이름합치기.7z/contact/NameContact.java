package com.biz.name.contact;

public class NameContact {
	
	public final static int FILES_SURNAME = 1;
	public final static int FILES_NAME = 0;
	public final static int FILES_FULLNAME = 2;
	
	public static int SC_strSurName = 0;
	public static int SC_strNum1 = 1;
	public static int SC_strHan = 2;
	public static int SC_strNum2 =3;
	
	public static int ST_strName = 0;
	
	

}
